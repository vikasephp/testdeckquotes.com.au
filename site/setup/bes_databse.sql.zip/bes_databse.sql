-- phpMyAdmin SQL Dump
-- version 2.8.0.1
-- http://www.phpmyadmin.net
-- 
-- Host: custsql-pow18
-- Generation Time: Jan 05, 2011 at 05:08 AM
-- Server version: 5.0.83
-- PHP Version: 4.4.9
-- 
-- Database: `bes_databse`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `bus_customers`
-- 

CREATE TABLE `bus_customers` (
  `bcust_id` int(11) NOT NULL auto_increment,
  `bcust_fname` varchar(200) NOT NULL,
  `bcust_lname` varchar(200) NOT NULL,
  `bcust_isbuyer` int(2) NOT NULL,
  `bcust_isseller` int(2) default NULL,
  `bcust_status` int(11) NOT NULL,
  `bcust_type` int(11) NOT NULL,
  `bcust_misc_email1` varchar(200) NOT NULL,
  `bcust_misc_email2` varchar(200) NOT NULL,
  `bcust_misc_send_market_email` int(2) NOT NULL,
  `bcust_misc_logged_date_date` date NOT NULL,
  `bcust_misc_logged_date_time` time NOT NULL,
  `bcust_misc_logged_user` varchar(200) NOT NULL,
  `bcust_misc_moble` varchar(25) NOT NULL,
  `bcust_misc_business` varchar(25) NOT NULL,
  `bcust_misc_home` varchar(25) NOT NULL,
  `bcust_gendec_sent_date` date default NULL,
  `bcust_gendec_sent_time` time default NULL,
  `bcust_gendec_signed_date` date default NULL,
  `bcust_gendec_signed_time` time default NULL,
  `bcust_gendec_comments` text,
  `bcust_gendec_file` varchar(200) default NULL,
  `bcust_address` varchar(500) NOT NULL,
  `bcust_suburb` varchar(50) NOT NULL,
  `bcust_postcode` varchar(50) NOT NULL,
  `bcust_state` varchar(50) NOT NULL,
  `bcust_country` varchar(50) NOT NULL,
  `bcust_postal_address` varchar(500) NOT NULL,
  `bcust_postal_suburb` varchar(50) NOT NULL,
  `bcust_postal_postcode` varchar(25) NOT NULL,
  `bcust_postal_state` varchar(50) NOT NULL,
  `bcust_postal_country` varchar(50) NOT NULL,
  `bcust_notes` text,
  PRIMARY KEY  (`bcust_id`)
) ENGINE=MyISAM AUTO_INCREMENT=87 DEFAULT CHARSET=latin1 AUTO_INCREMENT=87 ;

-- 
-- Dumping data for table `bus_customers`
-- 

INSERT INTO `bus_customers` VALUES (86, 'test', 'user', 1, 0, 1, 1, 'dhirtes@gmail.com', 'dhirtest@gmail.com', 0, '2010-09-07', '03:40:00', 'user', '', '', '', '2010-09-07', '03:40:00', '2010-09-07', '03:40:00', '', NULL, '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `bus_customers` VALUES (85, 'Doug', 'Stephenson', 1, 0, 1, 0, 'dwstephenson@gmail.com', '', 0, '2010-09-07', '02:28:00', 'user', '0412 206 222', '', '', '2010-09-07', '02:28:00', '2010-09-07', '02:28:00', '', NULL, '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `business`
-- 

CREATE TABLE `business` (
  `bsn_id` int(11) NOT NULL auto_increment,
  `bsn_name` varchar(500) NOT NULL,
  `bsn_status` int(11) NOT NULL,
  `bsn_status_date` date NOT NULL,
  `bsn_status_time` varchar(10) NOT NULL,
  `bsn_status_sys_date` date NOT NULL,
  `bsn_status_sys_time` time NOT NULL,
  `bsn_interest` int(11) NOT NULL,
  `bsn_date_listed_date` date NOT NULL,
  `bsn_date_listed_time` time NOT NULL,
  `bsn_readyforsale` int(2) default '0',
  `bsn_description` text NOT NULL,
  `bsn_address` varchar(200) NOT NULL,
  `bsn_suburb` varchar(100) NOT NULL,
  `bsn_state` varchar(100) default NULL,
  `bsn_pcode` varchar(100) default NULL,
  `bsn_cd_contact` varchar(200) NOT NULL,
  `bsn_cd_email` varchar(50) NOT NULL,
  `bsn_cd_phone` varchar(50) NOT NULL,
  `bsn_cd_fax` varchar(50) NOT NULL,
  `bsn_send_marketing_emails` int(3) NOT NULL default '0',
  `bsn_cd_date_appraised_date` date NOT NULL,
  `bsn_cd_date_appraised_time` time default NULL,
  `bsn_cd_appraised_by` varchar(200) NOT NULL,
  `bsn_cd_note` varchar(200) NOT NULL,
  `bsn_cd_planing_sell_date` date default NULL,
  `bsn_cd_planing_sell_time` time default NULL,
  `bsn_cd_enquiry_source` varchar(200) NOT NULL,
  `bsn_cd_org_ask_price` varchar(100) NOT NULL,
  `bsn_cd_current_ask_price` varchar(100) NOT NULL,
  `bsn_cd_ask_price_from` varchar(100) NOT NULL,
  `bsn_cd_ask_price_to` varchar(100) NOT NULL,
  `bsn_cd_cashflow` varchar(100) NOT NULL,
  `bsn_cd_turnover` varchar(100) NOT NULL,
  `bsn_cd_website` text NOT NULL,
  `bsn_cd_image_url` text NOT NULL,
  `bsn_cd_seller_summery` text NOT NULL,
  `bsn_agency_marketing` varchar(500) NOT NULL,
  `bsn_agent_marketing` varchar(500) NOT NULL,
  `bsn_agent_status` int(10) NOT NULL,
  `bsn_marketing_date` date NOT NULL,
  `bsn_marketing_time` time default NULL,
  `bsn_disclosed_marketing` int(3) NOT NULL,
  `bsn_undisclosed_name` varchar(200) NOT NULL,
  `bsn_franchise` int(3) NOT NULL,
  `bsn_franchise_name` varchar(200) NOT NULL,
  `bsn_marketing_price` varchar(20) NOT NULL,
  `bsn_stock_at_value` varchar(100) default NULL,
  `bsn_marketing_headline` varchar(500) NOT NULL,
  `bsn_marketing_note` text NOT NULL,
  `bsn_advertLink` text NOT NULL,
  `bsn_advert_text` text NOT NULL,
  `bsn_notes` text NOT NULL,
  `bsn_last_update_letter_date` date default NULL,
  `bsn_last_update_letter_time` time default NULL,
  PRIMARY KEY  (`bsn_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `business`
-- 

INSERT INTO `business` VALUES (6, 'Sumo Salad', 4, '2010-09-07', '03:12', '2010-09-07', '03:12:00', 4, '2010-09-07', '03:12:00', 0, 'An Australian-owned franchise, providing a healthy alternative to fast food. ', 'Westfield Woden Plaza ', 'Woden', 'ACT', '', 'Andrew Young', 'young_286@hotmail.com', '', '', 0, '2010-09-07', '03:12:00', '', '', '2010-09-07', '03:12:00', '0', '', '', ' $0', ' $0', '', '', '', '', '', '', '', 0, '2010-09-07', '03:12:00', 0, '', 0, '', '', '', '', '', '', '', '', '2010-09-07', '03:12:00');
INSERT INTO `business` VALUES (5, 'Sumo Salad', 4, '2010-09-07', '02:29', '2010-09-07', '02:29:00', 4, '2010-09-07', '02:29:00', 0, 'An Australian-owned franchise, providing a healthy alternative to fast food.', 'Westfield Woden Plaza', 'Woden', 'ACT', '', 'Andrew Young', 'young_286@hotmail.com', '', '', 0, '2010-09-07', '02:29:00', '', '', '2010-09-07', '02:29:00', '0', '', '', ' $0', ' $0', '', '', '', '', '', '', '', 0, '2010-09-07', '02:35:00', 0, '', 0, '', '', '', '', '', '', '', '', '2010-09-07', '02:35:00');

-- --------------------------------------------------------

-- 
-- Table structure for table `business_documents`
-- 

CREATE TABLE `business_documents` (
  `bd_id` int(11) NOT NULL auto_increment,
  `bd_user_id` int(11) NOT NULL,
  `bd_type` int(2) NOT NULL,
  `bd_status` int(2) NOT NULL,
  `bd_doc_name` varchar(400) NOT NULL,
  `bd_uploaded_date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `bd_bsi_id` int(11) NOT NULL,
  `bd_type_name` varchar(200) NOT NULL,
  `bd_comment` text NOT NULL,
  PRIMARY KEY  (`bd_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

-- 
-- Dumping data for table `business_documents`
-- 

INSERT INTO `business_documents` VALUES (3, 12, 5, 2, 'big_pictures_success_bash_26.jpg', '2010-08-27 13:14:10', 2, 'advert', 'sdf');
INSERT INTO `business_documents` VALUES (5, 12, 6, 1, 'big_pictures_success_bash_26.jpg', '2010-08-27 13:15:25', 2, 'Apprisal', 'ss');
INSERT INTO `business_documents` VALUES (6, 12, 6, 3, 'charter_school_pic_2_146232929_std.39195409.jpg', '2010-08-27 13:15:37', 2, 'Apprisal', 'xzczxc');
INSERT INTO `business_documents` VALUES (7, 12, 0, 1, '', '2010-08-27 16:12:46', 2, '', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `business_enquiry`
-- 

CREATE TABLE `business_enquiry` (
  `buse_id` int(11) NOT NULL auto_increment,
  `buse_bsn_id` int(11) NOT NULL,
  `buse_cust_id` int(11) NOT NULL,
  `buse_cust_name` varchar(200) NOT NULL,
  `buse_created_date` date NOT NULL,
  `buse_created_time` time NOT NULL,
  `buse_status` int(2) NOT NULL,
  `buse_source_of_enquiry` int(10) NOT NULL,
  `buse_source_of_other_enquiry` varchar(200) NOT NULL,
  `buse_comment` text NOT NULL,
  `buse_requested_information` text NOT NULL,
  `buse_answ_required` int(2) NOT NULL,
  `buse_initial_phone_call_date` date NOT NULL,
  `buse_initial_phone_call_time` time NOT NULL,
  `buse_initial_phone_call_comment` text,
  `buse_sent_dossier_date` date NOT NULL,
  `buse_sent_dossier_time` time NOT NULL,
  `buse_sent_dossier_comment` text,
  `buse_email_advice_sent_to_seller_date` date NOT NULL,
  `buse_email_advice_sent_to_seller_time` time NOT NULL,
  `buse_email_advice_sent_to_seller_comment` text NOT NULL,
  `buse_initial_phone_call_user` varchar(200) default NULL,
  `buse_sent_dossier_user` varchar(200) default NULL,
  `buse_email_advice_sent_to_seller_user` varchar(200) default NULL,
  PRIMARY KEY  (`buse_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `business_enquiry`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `business_file`
-- 

CREATE TABLE `business_file` (
  `bf_id` int(11) NOT NULL auto_increment,
  `bf_bsn_id` int(11) NOT NULL,
  `bf_name` varchar(500) NOT NULL,
  `bf_width` varchar(10) NOT NULL,
  `bf_height` varchar(10) NOT NULL,
  `bf_type` varchar(20) NOT NULL,
  `bf_attr` varchar(200) default NULL,
  `bf_role` int(2) NOT NULL,
  `bf_comments` text NOT NULL,
  PRIMARY KEY  (`bf_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

-- 
-- Dumping data for table `business_file`
-- 

INSERT INTO `business_file` VALUES (1, 2, 'globe.gif', '400', '357', '1', 'width="400" height="357"', 2, 'testsdf gf fgh');
INSERT INTO `business_file` VALUES (15, 4, 'apeejay_school_kharghar1.bmp', '436', '290', '6', 'width="436" height="290"', 1, 'dsffds');
INSERT INTO `business_file` VALUES (16, 2, 'charter_school_pic_2_146232929_std.39195409.jpg', '400', '300', '2', 'width="400" height="300"', 1, 'fdggfdg');
INSERT INTO `business_file` VALUES (14, 2, 'apeejay_school_kharghar1.bmp', '436', '290', '6', 'width="436" height="290"', 1, 'dsfdsf');
INSERT INTO `business_file` VALUES (13, 2, 'apeejay_school_kharghar1.bmp', '436', '290', '6', 'width="436" height="290"', 1, 'ds');
INSERT INTO `business_file` VALUES (17, 0, 'big_pictures_success_bash_26.jpg', '465', '700', '2', 'width="465" height="700"', 0, '');

-- --------------------------------------------------------

-- 
-- Table structure for table `business_interest`
-- 

CREATE TABLE `business_interest` (
  `bi_id` int(11) NOT NULL auto_increment,
  `bi_title` varchar(100) NOT NULL,
  `bi_status` int(2) default NULL,
  PRIMARY KEY  (`bi_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `business_interest`
-- 

INSERT INTO `business_interest` VALUES (1, 'Automotive', NULL);
INSERT INTO `business_interest` VALUES (2, 'Bars', NULL);
INSERT INTO `business_interest` VALUES (4, 'Food Outlets', NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `business_sellers`
-- 

CREATE TABLE `business_sellers` (
  `bs_id` int(11) NOT NULL auto_increment,
  `bs_business_id` int(11) NOT NULL,
  `bs_customers_id` int(11) NOT NULL,
  `bs_customers_name` varchar(200) NOT NULL,
  `bs_comments` text,
  PRIMARY KEY  (`bs_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `business_sellers`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `busness_status`
-- 

CREATE TABLE `busness_status` (
  `st_id` int(11) NOT NULL auto_increment,
  `st_name` varchar(100) NOT NULL,
  `st_status` int(2) default NULL,
  PRIMARY KEY  (`st_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `busness_status`
-- 

INSERT INTO `busness_status` VALUES (1, 'Prospact - Not on the Market', NULL);
INSERT INTO `busness_status` VALUES (3, 'Prospact - on Market other Agent', NULL);
INSERT INTO `busness_status` VALUES (4, 'Listed - Currently For Sale', NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `buyer_business_for_sale`
-- 

CREATE TABLE `buyer_business_for_sale` (
  `bbfs_id` int(11) NOT NULL auto_increment,
  `bbfs_cust_id` int(11) NOT NULL,
  `bbfs_bus_id` int(11) NOT NULL,
  `bbfs_user` int(11) default '0',
  `bbfs_business_name` varchar(500) NOT NULL,
  `bbfs_comments` text NOT NULL,
  PRIMARY KEY  (`bbfs_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `buyer_business_for_sale`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `byer_enquiry`
-- 

CREATE TABLE `byer_enquiry` (
  `be_id` int(11) NOT NULL auto_increment,
  `be_customer_id` int(11) NOT NULL,
  `be_business_id` int(11) NOT NULL,
  `be_user` int(11) NOT NULL default '0',
  `be_business_for_sell` int(11) NOT NULL,
  `be_status` int(2) NOT NULL,
  `be_created_date` date NOT NULL,
  `be_created_time` time NOT NULL,
  `be_source_of_enquiry` int(2) NOT NULL,
  `be_source_of_enquiry_other` varchar(200) NOT NULL,
  `be_comments` text NOT NULL,
  `be_request_info` text NOT NULL,
  `be_answer_required` int(2) NOT NULL,
  `be_ipc_date` date NOT NULL,
  `be_ipc_time` time NOT NULL,
  `be_ipc_comments` text NOT NULL,
  `be_easts_date` date NOT NULL,
  `be_easts_time` time NOT NULL,
  `be_easts_comments` text NOT NULL,
  `be_seller_email` varchar(200) NOT NULL,
  PRIMARY KEY  (`be_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `byer_enquiry`
-- 

INSERT INTO `byer_enquiry` VALUES (1, 85, 5, 12, 0, 1, '2010-09-07', '03:30:00', 11, '', '', '', 1, '2010-09-07', '03:30:00', '', '2010-09-07', '03:30:00', '', '');
INSERT INTO `byer_enquiry` VALUES (3, 85, 6, 12, 0, 1, '2010-09-07', '03:57:00', 7, '', '', '', 1, '2010-09-07', '03:57:00', '', '2010-09-07', '03:57:00', '', '');
INSERT INTO `byer_enquiry` VALUES (5, 86, 5, 12, 0, 1, '2010-09-07', '03:42:00', 7, '', 'dsf sf', '', 1, '2010-09-07', '03:42:00', '', '2010-09-07', '03:42:00', '', '');
INSERT INTO `byer_enquiry` VALUES (6, 86, 6, 12, 0, 1, '2010-09-07', '03:59:00', 2, '', '', '', 1, '2010-09-07', '03:59:00', '', '2010-09-07', '03:59:00', '', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `customer_business`
-- 

CREATE TABLE `customer_business` (
  `custbus_id` int(11) NOT NULL auto_increment,
  `cust_id` int(11) NOT NULL,
  `bus_id` int(11) NOT NULL,
  PRIMARY KEY  (`custbus_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

-- 
-- Dumping data for table `customer_business`
-- 

INSERT INTO `customer_business` VALUES (1, 3, 2);
INSERT INTO `customer_business` VALUES (4, 2, 4);
INSERT INTO `customer_business` VALUES (7, 18, 2);

-- --------------------------------------------------------

-- 
-- Table structure for table `customers`
-- 

CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_address` varchar(255) NOT NULL,
  `customer_city` varchar(255) NOT NULL,
  `customer_state` varchar(255) NOT NULL,
  `customer_country` varchar(5) NOT NULL,
  `customer_zip` varchar(15) NOT NULL,
  `customer_phone` varchar(15) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  PRIMARY KEY  (`customer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `customers`
-- 

INSERT INTO `customers` VALUES (1, 12, 'Dharmendra Pardhi', 'Chhota Gondia', 'Gondia', 'AL', 'US', '441614', '9028381460', 'dharmendra@ephpsolutions.com');

-- --------------------------------------------------------

-- 
-- Table structure for table `customers_status`
-- 

CREATE TABLE `customers_status` (
  `cs_id` int(11) NOT NULL auto_increment,
  `cs_name` varchar(300) NOT NULL,
  `cs_status` int(2) NOT NULL default '0',
  PRIMARY KEY  (`cs_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `customers_status`
-- 

INSERT INTO `customers_status` VALUES (1, 'Active', 0);
INSERT INTO `customers_status` VALUES (2, 'Inactive', 0);
INSERT INTO `customers_status` VALUES (3, 'New Registration', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `customers_type`
-- 

CREATE TABLE `customers_type` (
  `ct_id` int(11) NOT NULL auto_increment,
  `ct_name` varchar(300) NOT NULL,
  `ct_status` int(2) NOT NULL default '0',
  PRIMARY KEY  (`ct_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `customers_type`
-- 

INSERT INTO `customers_type` VALUES (1, 'Accountant', 0);
INSERT INTO `customers_type` VALUES (2, 'Agent', 0);
INSERT INTO `customers_type` VALUES (3, 'Lawyer', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `document_types`
-- 

CREATE TABLE `document_types` (
  `dt_id` int(11) NOT NULL auto_increment,
  `dt_name` varchar(300) NOT NULL,
  `dt_status` int(2) NOT NULL default '0',
  PRIMARY KEY  (`dt_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `document_types`
-- 

INSERT INTO `document_types` VALUES (5, 'advert', 0);
INSERT INTO `document_types` VALUES (6, 'Apprisal', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `enquirysource`
-- 

CREATE TABLE `enquirysource` (
  `soe_id` int(11) NOT NULL auto_increment,
  `soe_name` varchar(200) NOT NULL,
  `soe_status` int(2) NOT NULL,
  PRIMARY KEY  (`soe_id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

-- 
-- Dumping data for table `enquirysource`
-- 

INSERT INTO `enquirysource` VALUES (2, 'All Homes', 0);
INSERT INTO `enquirysource` VALUES (3, 'Canderra Times', 0);
INSERT INTO `enquirysource` VALUES (4, 'Commercial Real Estate', 0);
INSERT INTO `enquirysource` VALUES (5, 'Database', 0);
INSERT INTO `enquirysource` VALUES (6, 'Domain', 0);
INSERT INTO `enquirysource` VALUES (7, 'Email', 0);
INSERT INTO `enquirysource` VALUES (8, 'Other', 0);
INSERT INTO `enquirysource` VALUES (9, 'PB Commercial', 0);
INSERT INTO `enquirysource` VALUES (10, 'Phone', 0);
INSERT INTO `enquirysource` VALUES (11, 'Real Commercial', 0);
INSERT INTO `enquirysource` VALUES (12, 'Seek', 0);
INSERT INTO `enquirysource` VALUES (13, 'TBC', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `groups`
-- 

CREATE TABLE `groups` (
  `group_id` int(10) NOT NULL auto_increment,
  `group_name` varchar(255) default NULL,
  PRIMARY KEY  (`group_id`),
  UNIQUE KEY `name` (`group_name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `groups`
-- 

INSERT INTO `groups` VALUES (1, 'Administrators');
INSERT INTO `groups` VALUES (2, 'Customers');
INSERT INTO `groups` VALUES (3, 'Users');

-- --------------------------------------------------------

-- 
-- Table structure for table `pages`
-- 

CREATE TABLE `pages` (
  `page_id` int(11) NOT NULL auto_increment,
  `page_level` smallint(6) NOT NULL default '0',
  `page_lineage` text NOT NULL,
  `page_parent_id` int(11) NOT NULL,
  `page_post_slug` varchar(255) NOT NULL,
  `page_action` varchar(255) NOT NULL,
  `page_action_params` varchar(255) NOT NULL,
  `page_date_created` datetime NOT NULL,
  `page_date_modified` datetime NOT NULL,
  `page_published` tinyint(1) NOT NULL default '0',
  `page_date_published` datetime NOT NULL default '0000-00-00 00:00:00',
  `page_date_retracted` datetime NOT NULL default '0000-00-00 00:00:00',
  `page_sort` smallint(6) NOT NULL default '0',
  `page_title` varchar(255) NOT NULL,
  `page_short_title` varchar(500) NOT NULL,
  `page_metadesc` text NOT NULL,
  `page_metakeyword` text NOT NULL,
  `page_body` mediumtext NOT NULL,
  PRIMARY KEY  (`page_id`),
  KEY `page_post_slug` (`page_post_slug`(15))
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

-- 
-- Dumping data for table `pages`
-- 

INSERT INTO `pages` VALUES (1, 0, '/1', -1, 'top-menu.htm', '', '', '2010-05-15 11:09:41', '2010-05-15 11:09:41', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'Top Menu', '', '', '', '');
INSERT INTO `pages` VALUES (2, 0, '/2', -1, 'main-menu.htm', '', '', '2010-05-15 11:09:54', '2010-05-15 11:09:54', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'Main Menu', '', '', '', '');
INSERT INTO `pages` VALUES (3, 0, '/3', -1, 'bottom-menu.htm', '', '', '2010-05-15 11:10:04', '2010-05-15 11:10:04', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'Bottom Menu', '', '', '', '');
INSERT INTO `pages` VALUES (4, 0, '/4', -1, 'home.htm', 'site.home', '', '2010-05-15 11:11:04', '2010-08-30 05:05:35', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'Home', '', '', '', '');
INSERT INTO `pages` VALUES (5, 1, '/3/5', 3, 'contact-us.htm', 'site.contact', '', '2010-05-15 11:12:21', '2010-05-15 12:07:01', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'Contact Us', '', '', '', '');
INSERT INTO `pages` VALUES (6, 1, '/1/6', 1, 'login.htm', 'site.login', '', '2010-05-15 11:16:51', '2010-05-15 11:24:51', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'login', '', '', '', '');
INSERT INTO `pages` VALUES (7, 0, '/7', -1, 'logout.htm', 'site.logout', '', '2010-05-15 11:22:59', '2010-05-15 11:22:59', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'logout', '', '', '', '');
INSERT INTO `pages` VALUES (8, 1, '/1/8', 1, 'register.htm', 'site.register', '', '2010-05-15 11:24:39', '2010-05-15 11:24:39', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'Register', '', '', '', '');
INSERT INTO `pages` VALUES (9, 1, '/1/9', 1, 'reviews.htm', 'reviews.list', '', '2010-05-15 11:25:09', '2010-06-07 18:16:40', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'Reviews', '', '', '', '<p>\r\n	Retailers - Testing text goes here...<br />\r\n	<img alt=" " border="0" height="4" src="http://www.loremipsum.net/pics/pixel.gif" width="360" /></p>\r\n<p>\r\n	Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum.</p>\r\n<p>\r\n	Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.</p>\r\n');
INSERT INTO `pages` VALUES (10, 1, '/3/10', 3, 'about-us.htm', '', '', '2010-05-15 11:25:52', '2010-05-15 15:40:05', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'About Us', '', '', '', '<p>\r\n	About Us - Testing text goes here...<br />\r\n	<img alt=" " border="0" height="4" src="http://www.loremipsum.net/pics/pixel.gif" width="360" /></p>\r\n<p>\r\n	Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum.</p>\r\n<p>\r\n	Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.</p>\r\n');
INSERT INTO `pages` VALUES (11, 1, '/3/11', 3, 'careers.htm', '', '', '2010-05-15 11:26:34', '2010-05-15 11:26:34', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'Careers', '', '', '', '');
INSERT INTO `pages` VALUES (12, 1, '/3/12', 3, 'news-.htm', '', '', '2010-05-15 11:26:45', '2010-05-15 11:26:45', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'News ', '', '', '', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

CREATE TABLE `users` (
  `user_id` int(10) NOT NULL auto_increment,
  `user_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_username` varchar(32) NOT NULL,
  `user_password` varchar(32) NOT NULL,
  PRIMARY KEY  (`user_id`),
  UNIQUE KEY `username` (`user_username`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

-- 
-- Dumping data for table `users`
-- 

INSERT INTO `users` VALUES (1, 'Administrator', 'admin@localhost', 'admin', '21232f297a57a5a743894a0e4a801fc3');
INSERT INTO `users` VALUES (12, 'user', 'dhi@gmail.om', 'user', 'ee11cbb19052e40b07aac0ca060c23ee');

-- --------------------------------------------------------

-- 
-- Table structure for table `users_groups`
-- 

CREATE TABLE `users_groups` (
  `user_id` int(10) NOT NULL default '0',
  `group_id` int(10) NOT NULL default '0',
  PRIMARY KEY  (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `users_groups`
-- 

INSERT INTO `users_groups` VALUES (12, 2);
INSERT INTO `users_groups` VALUES (1, 1);
