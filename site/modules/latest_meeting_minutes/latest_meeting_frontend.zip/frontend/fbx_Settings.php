<?php
/*
<fusedoc fuse="fbx_Settings.php">
	<responsibilities>
		I set up the enviroment settings for this circuit. If this settings file is being inherited, then you can set a variable outright to override a value set in a parent circuit or use if(!isset(...)) to accept a value set by a parent circuit
	</responsibilities>
</fusedoc>
*/
require_once(MODULES_DIR . 'frontend.init.php');
$fwAuthGroup->forceLogin();

// module names
$MODULE_SINGULAR = 'Last Meeting Minutes';
$MODULE_PLURAL =   'Last Meeting Minutes';

$fwViewData['MODULE_SINGULAR'] = $MODULE_SINGULAR;
$fwViewData['MODULE_PLURAL'] = $MODULE_PLURAL;

// module table and id
// $TABLE = 'debt_management';
// $ID = 'dm_id';
$TABLE = 'last_meeting_minutes';
$ID = 'lmm_id';
$fwViewData['TABLE'] = $TABLE;
$fwViewData['ID'] = $ID;

// fuseactions
$XFA['list'] = $Fusebox['circuit'] . '.list';
$XFA['detail'] = $Fusebox['circuit'] . '.detail';
$XFA['home'] = $Fusebox['circuit'] . '.home';
$XFA['delete'] = $Fusebox['circuit'] . '.delete';
$XFA['replay'] = $Fusebox['circuit'] . '.replay';


function upload($filename, $tmpname)
{
    $path = getcwd();
    $zipfile = $filename;

    $resource_id = 1;
    $error_type = "File Uploading to AWS Bucket";

    header('Access-Control-Allow-Origin: *');
    $filetoinclude = $_SERVER['DOCUMENT_ROOT'] . '/file_upload/server/s3/S3.php';
    include_once $filetoinclude;
    $date = date("Y-m-d H:i:s");
    try {
        if (move_uploaded_file($tmpname, $path . '/' .  basename($zipfile))) {
            $s3 = new S3(ACCESS_KEY, SECRET_KEY);
            $flag = 0;
            if ($s3->putObjectFile($path . "/" . $zipfile, 'deckquote', 'files/document_check_list_files/' . $zipfile, S3::ACL_PRIVATE)) {
                $flag = 1;
            } else {
                sleep(10);
                if ($s3->putObjectFile($path . "/" . $zipfile, 'deckquote',  'files/document_check_list_files/' . $zipfile, S3::ACL_PRIVATE))
                    $flag = 1;
            }
        } else {
        }
    } catch (ErrorException $ex) {
        echo $ex->getLine();
        return false;
    }

    $rem = $path . '/' .  basename($filename);
    unlink($rem);
    return $flag;
}
